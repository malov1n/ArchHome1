// Прелоадер
window.addEventListener('load', () => {
    setTimeout(() => {
        document.getElementById('preloader').classList.add('hidden');
    }, 1200);
});

// Расширенные данные проектов
const projects = [
    {
        id: 1,
        title: 'Резиденция «Монолит»',
        location: 'Москва, Патриаршие пруды',
        category: 'residential',
        type: 'Жилой комплекс премиум-класса',
        mainImage: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '12 500 м²', 'Этажность': '24 этажа', 'Квартир': '128', 'Паркинг': 'Подземный на 200 мест', 'Архитектор': 'Александр Морозов', 'Год': '2024' },
        description: 'Резиденция «Монолит» — это воплощение современной архитектурной мысли. Здание расположено в историческом центре Москвы и представляет собой монументальное сооружение с выразительным фасадом из натурального камня и стекла.',
        features: ['Панорамное остекление', 'Умный дом', 'Фитнес-центр', 'Спа-зона', 'Детская комната', 'Консьерж-сервис', 'Подземный паркинг', 'Охраняемая территория']
    },
    {
        id: 2,
        title: 'Бизнес-центр «Кристалл»',
        location: 'Москва, Москва-Сити',
        category: 'commercial',
        type: 'Бизнес-центр класса А+',
        mainImage: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210491892-03f54c0c65e7?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '45 000 м²', 'Этажность': '38 этажей', 'Офисов': '200+', 'Паркинг': '500 мест', 'Архитектор': 'Дмитрий Ковалёв', 'Год': '2025' },
        description: 'Бизнес-центр «Кристалл» — это современное офисное пространство в сердце делового квартала Москва-Сити. Энергоэффективные технологии и панорамные виды.',
        features: ['Конференц-залы', 'Ресторан', 'Фитнес-центр', 'Sky-лаунж', 'Подземный паркинг', 'Климат-контроль', 'Скоростные лифты', 'Охрана 24/7']
    },
    {
        id: 3,
        title: 'Лофт «Геометрия»',
        location: 'Москва, Даниловская мануфактура',
        category: 'residential',
        type: 'Лофт-комплекс',
        mainImage: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210491892-03f54c0c65e7?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '8 200 м²', 'Этажность': '12 этажей', 'Лофтов': '86', 'Паркинг': 'Наземный', 'Архитектор': 'Анна Соколова', 'Год': '2024' },
        description: 'Лофт-комплекс на территории бывшей мануфактуры. Кирпичная кладка XIX века сочетается с современными конструкциями.',
        features: ['Потолки 6 м', 'Кирпичные стены', 'Коворкинг', 'Галерея', 'Второй свет', 'Открытая планировка', 'Тёплые полы', 'Мультимедиа']
    },
    {
        id: 4,
        title: 'Культурный центр «Арка»',
        location: 'Санкт-Петербург, Крестовский остров',
        category: 'public',
        type: 'Общественное здание',
        mainImage: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600210491892-03f54c0c65e7?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '15 000 м²', 'Этажность': '5 этажей', 'Залов': '3 концертных', 'Паркинг': 'Подземный', 'Архитектор': 'Елена Ветрова', 'Год': '2023' },
        description: 'Многофункциональный культурный центр с концертным залом на 800 мест, выставочными галереями и библиотекой.',
        features: ['Концертный зал', 'Галерея', 'Библиотека', 'Лекторий', 'Кафе', 'Детская зона', 'Арт-резиденция', 'Кинозал']
    },
    {
        id: 5,
        title: 'Офисный парк «Небо»',
        location: 'Москва, Ленинградский проспект',
        category: 'commercial',
        type: 'Офисный парк',
        mainImage: 'https://images.unsplash.com/photo-1600585153490-76fb20a32601?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210491892-03f54c0c65e7?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '28 000 м²', 'Корпусов': '4', 'Офисов': '150', 'Паркинг': '300 мест', 'Архитектор': 'Александр Морозов', 'Год': '2024' },
        description: 'Современный деловой квартал с собственной инфраструктурой и ландшафтным парком.',
        features: ['Зелёный двор', 'Кафе', 'Фитнес', 'Конференц-центр', 'Вело-парковка', 'Электрозаправки', 'Террасы', 'Охрана']
    },
    {
        id: 6,
        title: 'Жилой комплекс «Сады»',
        location: 'Москва, Раменки',
        category: 'residential',
        type: 'Жилой комплекс',
        mainImage: 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&h=600&fit=crop',
        gallery: [
            'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop'
        ],
        interior: [
            'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600585152220-90363fe7e115?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600566753086-00f18f6b0050?w=800&h=600&fit=crop',
            'https://images.unsplash.com/photo-1600210491892-03f54c0c65e7?w=800&h=600&fit=crop'
        ],
        specs: { 'Площадь': '18 000 м²', 'Этажность': '18 этажей', 'Квартир': '240', 'Паркинг': 'Подземный', 'Архитектор': 'Анна Соколова', 'Год': '2023' },
        description: 'Жилой комплекс в экологически чистом районе. Концепция — гармония архитектуры и природы.',
        features: ['Парк', 'Детский сад', 'Школа', 'Бассейн', 'Террасы', 'Консьерж', 'Фитнес', 'Игровые площадки']
    }
];

// Рендер проектов
const projectsGrid = document.getElementById('projectsGrid');

function renderProjects(filter = 'all') {
    const filtered = filter === 'all' ? projects : projects.filter(p => p.category === filter);
    projectsGrid.innerHTML = filtered.map((p, i) => `
        <div class="project-card ${i === 0 ? 'large' : ''}" data-id="${p.id}">
            <img src="${p.mainImage}" alt="${p.title}">
            <div class="project-info">
                <span class="project-type">${p.type}</span>
                <h3>${p.title}</h3>
                <p class="project-location">📍 ${p.location}</p>
                <p class="project-card-desc">${p.description.substring(0, 120)}...</p>
                <div class="project-card-specs">
                    ${Object.entries(p.specs).slice(0, 4).map(([k,v]) => `<span>${v}</span>`).join('')}
                </div>
            </div>
        </div>
    `).join('');
}

// Фильтры
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderProjects(btn.dataset.filter);
    });
});

// Детальная страница
const projectPage = document.getElementById('projectPage');
const projectPageContent = document.getElementById('projectPageContent');

function openProject(id) {
    const p = projects.find(pr => pr.id === id);
    if (!p) return;

    projectPageContent.innerHTML = `
        <div class="project-gallery">
            <div class="gallery-main"><img src="${p.mainImage}" alt=""></div>
            <div class="gallery-side">
                ${p.gallery.map(img => `<img src="${img}" alt="">`).join('')}
            </div>
        </div>
        <div class="project-details">
            <div class="project-details-header">
                <div>
                    <div class="section-label">${p.type}</div>
                    <h1 class="project-details-title">${p.title}</h1>
                    <p style="color:var(--purple);margin-top:10px;">📍 ${p.location}</p>
                </div>
                <p class="project-description">${p.description}</p>
            </div>
            <div class="project-specs">
                ${Object.entries(p.specs).map(([k,v]) => `
                    <div class="spec-item"><div class="spec-label">${k}</div><div class="spec-value">${v}</div></div>
                `).join('')}
            </div>
            <div style="margin:50px 0;">
                <div class="section-label">Особенности</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:20px;">
                    ${p.features.map(f => `<div style="padding:15px;border:1px solid #e0e0e0;">${f}</div>`).join('')}
                </div>
            </div>
            <div class="section-label">Интерьеры</div>
            <div class="interior-gallery">
                ${p.interior.map(img => `<img src="${img}" alt="">`).join('')}
            </div>
        </div>
    `;
    projectPage.classList.add('active');
    document.body.style.overflow = 'hidden';
}

projectsGrid.addEventListener('click', e => {
    const card = e.target.closest('.project-card');
    if (card) openProject(parseInt(card.dataset.id));
});

document.getElementById('backBtn').addEventListener('click', () => {
    projectPage.classList.remove('active');
    document.body.style.overflow = '';
});

// Счётчики
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            document.querySelectorAll('[data-target]').forEach(el => {
                const target = parseInt(el.dataset.target);
                let current = 0;
                const timer = setInterval(() => {
                    current += Math.ceil(target / 30);
                    if (current >= target) { el.textContent = target; clearInterval(timer); }
                    else { el.textContent = current; }
                }, 30);
            });
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

const statsSection = document.querySelector('.stats');
if (statsSection) observer.observe(statsSection);

// Плавный скролл
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
});

// Инициализация
renderProjects();